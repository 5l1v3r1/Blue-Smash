char *replace(char *string, char *oldpiece, char *newpiece);
