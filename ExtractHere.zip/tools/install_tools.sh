#!/bin/bash

make
make install

echo -en "\n<<< Compiling btftp\n"
cd btftp_src
make
mv btftp /usr/bin
make clean
cd ..

echo -en "\n<<< Compiling btobex\n"
cd btobex_src
make
mv btobex /usr/bin
make clean
cd ..

echo -en "\n<<< Compiling bss\n"
cd bss-0.8
make
make install
make clean
cd ..

echo -en "\n<<< Compiling hidattack\n"
cd hidattack01
make
mv hidattack /usr/bin
cd ..